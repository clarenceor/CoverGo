﻿using Domain;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestsNUnit
{
    public class DiscountForJeans
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void DiscountCalculation()
        {
            Cart cart = new Cart();
            cart.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart.CalculateCartValue() == 40);
        }

        [Test]
        public void DiscountCalculationForMoreThanThree()
        {
            //More than 3 jeans
            Cart cart2 = new Cart();
            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart2.CalculateCartValue() == 80);
        }

        [Test]
        public void DiscountCalculationForMultipleOfThree()
        {
            //6 jeans
            Cart cart2 = new Cart();
            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart2.CalculateCartValue() == 80);
        }

        [Test]
        public void DiscountCalculationFour()
        {
            //4 jeans
            Cart cart2 = new Cart();
            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart2.CalculateCartValue() == 60);
        }

        [Test]
        public void DiscountCalculationOne()
        {
            //6 jeans
            Cart cart2 = new Cart();
            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart2.CalculateCartValue() == 20);
        }

        [Test]
        public void DiscountCalculationTwo()
        {
            //2 jeans
            Cart cart2 = new Cart();
            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            cart2.addToCart(new ProductMaster()
            {
                Price = 20,
                ProductName = "Jeans",
                ProductId = 2
            });

            Assert.IsTrue(cart2.CalculateCartValue() == 40);
        }
    }
}
