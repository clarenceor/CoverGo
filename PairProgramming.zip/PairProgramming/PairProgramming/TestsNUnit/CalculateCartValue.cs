﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;
using NUnit.Framework;

namespace TestsNUnit
{
    public class CalculateCartValue
    {
        private ProductA productA;
        private ProductB productB;

        [SetUp]
        public void Setup()
        {
            productA = new ProductA()
            {
                ProductId = 1,
                Price = 10
            };

            productB = new ProductB()
            {
                ProductId = 2,
                Price = 20
            };
        }

        [Test]
        public void CartValueCalculation()
        {
            //Case Jeans & Tshirt
            Cart cart = new Cart();

            //Tshirt
            cart.addToCart(new ProductMaster
            {
                Price = 10,
                ProductId = 1,
                ProductName = "T-shirt"
            });

            //Jeans
            cart.addToCart(new ProductMaster
            {
                Price = 20,
                ProductId = 2,
                ProductName = "Jeans"
            });

            Assert.IsTrue(cart.CalculateCartValue() == 30);
        }
    }
}
