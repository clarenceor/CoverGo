using Domain;
using NUnit.Framework;

namespace TestsNUnit
{
    public class Tests
    {
        private ProductA productA;
        private ProductB productB;

        [SetUp]
        public void Setup()
        {
            productA = new ProductA()
            {
                ProductId = 1,
                Price = 50
            };

            productB = new ProductB()
            {
                ProductId = 2,
                Price = 50
            };
        }

        [Test]
        public void Test1()
        {
            Cart cart = new Cart();
            cart.addToCart(productA);
            cart.addToCart(productB);
            Assert.IsTrue(cart.products.Count == 2);

            cart.removeFromCart(2);
            Assert.IsTrue(cart.products.Count == 1);
        }
    }
}