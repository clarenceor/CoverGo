﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Service
{
    public interface ICartService
    {
        void addToCart(ProductMaster product);
        void removeFromCart(int productId);

        decimal CalculateCartValue();
    }
}
