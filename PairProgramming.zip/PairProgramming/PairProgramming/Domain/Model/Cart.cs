﻿using Domain.Service;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Domain
{
    public class Cart : ICartService
    {
        private List<ProductMaster> _products { get; set; } = new List<ProductMaster>();
        public List<ProductMaster> products 
        {
            get
            {
                return _products;
            } 
        }

        public void addToCart(ProductMaster product)
        {
            _products.Add(product);
        }

        public void removeFromCart(int productId)
        {
            _products.RemoveAll(x => x.ProductId == productId);
        }

        public decimal CalculateCartValue()
        {
            decimal tempPrice = 0;
            foreach (var product in _products.Where(x => !IsInDiscount(x.ProductId)))
            {
               tempPrice += product.Price;
            }

            tempPrice += CalculateDiscountedCartValue();

            return tempPrice;
        }

        private bool IsInDiscount(int productId)
        {
            if (productId == 2)
            {
                return true;
            }

            return false;
        }

        private decimal CalculateDiscountedCartValue()
        {
            decimal tempDiscountedPrice = 0;

            var Jeans = _products.Where(x => x.ProductId == 2);

            if (Jeans.Count() % 3 == 0)
            {
                tempDiscountedPrice = Jeans.Sum(x => x.Price) / 3m * 2m;
            }
            else if (Jeans.Count() % 3 == 2 || Jeans.Count() % 3 == 1)
            {
                tempDiscountedPrice = Jeans.Sum(x => x.Price) - (Jeans.Count() > 3 ? Jeans.FirstOrDefault().Price : 0);
            }

            return tempDiscountedPrice;
        }
    }
}